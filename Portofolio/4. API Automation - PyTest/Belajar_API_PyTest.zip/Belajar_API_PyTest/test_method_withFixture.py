import requests
import pytest


# Fixture untuk membuat board sebelum test dan menghapus setelah test
@pytest.fixture
def create_board():
    url = 'https://api.trello.com/1/boards/'
    params = {
        'key': '7939e748f1cad4f452d5903ea3114642',
        'token': 'ATTA31a9111b6c6b182d3ea3e67007faa1f4ea24ea613ef1e02dc8c71690d0f8193212800E79',
        'name': 'Test Board Fixture'
    }
    response = requests.post(url, params=params)
    assert response.status_code == 200

    board = response.json()
    yield board  # <-- Ini yang dikirim ke test sebagai argumen (board dict)

    # 🔥 Cleanup: delete board setelah test selesai
    board_id = board["id"]
    delete_url = f"https://api.trello.com/1/boards/{board_id}"
    delete_params = {
        'key': '7939e748f1cad4f452d5903ea3114642',
        'token': 'ATTA31a9111b6c6b182d3ea3e67007faa1f4ea24ea613ef1e02dc8c71690d0f8193212800E79'
    }
    delete_resp = requests.delete(delete_url, params=delete_params)
    assert delete_resp.status_code == 200

# Test GET board berdasarkan board yang dibuat oleh fixture
def test_get_board(create_board):
    board_id = create_board["id"]
    expected_name = create_board["name"]

    url = f"https://api.trello.com/1/boards/{board_id}"
    params = {
        'key': '7939e748f1cad4f452d5903ea3114642',
        'token': 'ATTA31a9111b6c6b182d3ea3e67007faa1f4ea24ea613ef1e02dc8c71690d0f8193212800E79'
    }

    response = requests.get(url, params=params)
    assert response.status_code == 200

    json_response = response.json()
    print(json_response)

    assert json_response["name"] == expected_name
