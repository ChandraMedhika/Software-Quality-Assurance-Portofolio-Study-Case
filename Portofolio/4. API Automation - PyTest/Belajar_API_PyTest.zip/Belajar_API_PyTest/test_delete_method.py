import requests
import json
import jsonpath
import pytest

def test_delate():
    url = "https://api.trello.com/1/boards/6875bd3b74a46f7b2bd99435"
    query = {
        "key" : "7939e748f1cad4f452d5903ea3114642",
        "token" : "ATTA31a9111b6c6b182d3ea3e67007faa1f4ea24ea613ef1e02dc8c71690d0f8193212800E79"
    }
    
    response = requests.delete(url,params=query)
    
    code = response.status_code
    assert code
    
    json_response = json.loads(response.text)
    value = jsonpath.jsonpath(json_response, '_value')
    
    assert value[0] == None