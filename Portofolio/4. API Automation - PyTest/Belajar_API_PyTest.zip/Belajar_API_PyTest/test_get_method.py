import requests
import pytest
import json

def test_get_method():
    
    url = 'https://api.trello.com/1/boards/6875d034859e8d0026dd1e43'
    
    query = {
            'key':'7939e748f1cad4f452d5903ea3114642',
            'token':'ATTA31a9111b6c6b182d3ea3e67007faa1f4ea24ea613ef1e02dc8c71690d0f8193212800E79',
    }
    response = requests.get(url, params=query)
    
    #print(response.json())
    
    json_response = json.loads(response.text)
    #Tampilkan body JSON dengan rapi
    print(json.dumps(json_response, indent=2))
    
    code = response.status_code
    
    assert code == 200
    
    assert response.json()["name"] == "Test via Pytest"